/*package com.financial.services.batonsystems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatonsystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/