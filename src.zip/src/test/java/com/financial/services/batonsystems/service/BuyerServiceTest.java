package com.financial.services.batonsystems.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.financial.services.batonsystems.entity.BuyerEntity;
import com.financial.services.batonsystems.entity.TradeEntity;

@ExtendWith(MockitoExtension.class)
public class BuyerServiceTest {
	
	@Mock
	BuyerService buyerService;
	
	@Before
	public void initializeTestRequestPayload() throws IOException {
		MockitoAnnotations.initMocks(this);
		buyerService = Mockito.mock(BuyerService.class);
	}

	@Test
	public void testBuyerService() {
		BuyerEntity buyer = returnBuyerModel();
		buyerService.buyTrade(buyer);
		List<TradeEntity> matchedRecord = buyerService.matchedRecordsBySymbolPrice("IBM", "Party A", "Party B");
		List<BuyerEntity> nonMatchedRecord = buyerService.nonMatchedRecords("IBM", 110);
		assertNotNull(matchedRecord);
		assertNotNull(nonMatchedRecord);
	}



	private BuyerEntity returnBuyerModel() {
		BuyerEntity buyerModel = new BuyerEntity();
		buyerModel.setBuyerId("Party B");
		buyerModel.setId(2);
		buyerModel.setPrice(110);
		buyerModel.setStock("IBM");
		buyerModel.setTradeDate(new Date());
		return null;
	}
}
