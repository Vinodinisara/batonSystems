/*package com.financial.services.batonsystems.controller;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.MOCK, classes={ TradeControllerTest.class })
public class TradeControllerTest {
	
	 private MockMvc mockMvc;

	  @Autowired
	  private WebApplicationContext webApplicationContext;


	  @Before
	  public void setUp() {
	    this.mockMvc = webAppContextSetup(webApplicationContext).build();
	  }
	  
	  @Test
	  public void successResponseSell() throws Exception {
		  this.mockMvc.perform(post("/v1/sell")
	           .contentType(MediaType.APPLICATION_JSON)
	           .content("{sellerId: Party A, stock: INFY, price: 158 }") 
	           .accept(MediaType.APPLICATION_JSON))
		  	   .andExpect(status().isOk());
	  }
	  
	  @Test
	  public void successResponseBuy() throws Exception {
		  this.mockMvc.perform(post("/v1/buy")
	           .contentType(MediaType.APPLICATION_JSON)
	           .content("{buyerId: Party B, stock: INFY, price: 158 }") 
	           .accept(MediaType.APPLICATION_JSON))
		  	   .andExpect(status().isOk());
	  }
}
*/