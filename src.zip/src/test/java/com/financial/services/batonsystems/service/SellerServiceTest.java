package com.financial.services.batonsystems.service;

import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.financial.services.batonsystems.entity.SellerEntity;

@ExtendWith(MockitoExtension.class)
public class SellerServiceTest {
	
	@Mock
	SellerService sellerService;
	
	@Before
	public void initializeTestRequestPayload() throws IOException {
		MockitoAnnotations.initMocks(this);
		sellerService = Mockito.mock(SellerService.class);
	}

	@Test
	public void testBuyerService() {
		SellerEntity seller = returnSellerModel();
		sellerService.sellTrade(seller);
		assertNull(seller);
	}



	private SellerEntity returnSellerModel() {
		SellerEntity buyerModel = new SellerEntity();
		buyerModel.setSellerId("Party A");
		buyerModel.setId(2);
		buyerModel.setPrice(110);
		buyerModel.setStock("IBM");
		buyerModel.setTradeDate(new Date());
		return null;
	}

}
