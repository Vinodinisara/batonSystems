package com.financial.services.batonsystems.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.entity.BuyerEntity;
import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.TradeEntity;


/**
 * @author Vinodini
 * 
 *    Interface to buy stocks
 *
 */
@Component
public interface BuyerService {

	public ResponseModel buyTrade(BuyerEntity buyer);
	
	public List<TradeEntity> matchedRecordsBySymbolPrice(String symbol, String sellerId, String buyerId);
	
	public List<BuyerEntity> nonMatchedRecords(String symbol, float price);
}
