package com.financial.services.batonsystems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatonsystemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatonsystemsApplication.class, args);
	}

}
