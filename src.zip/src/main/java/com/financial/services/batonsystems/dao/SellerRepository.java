package com.financial.services.batonsystems.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.entity.SellerEntity;

@Component
public interface SellerRepository extends CrudRepository<SellerEntity, String> {

}
