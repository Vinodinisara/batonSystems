package com.financial.services.batonsystems.service;

import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.SellerEntity;


/**
 * @author Vinodini
 * 
 *    Interface to sell stocks
 *
 */
@Component
public interface SellerService {
	
	public ResponseModel sellTrade(SellerEntity seller);

}
