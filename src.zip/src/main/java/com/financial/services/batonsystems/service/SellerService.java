package com.financial.services.batonsystems.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.dao.SellerRepository;
import com.financial.services.batonsystems.entity.ResponseEntity;
import com.financial.services.batonsystems.entity.SellerEntity;

@Component
public class SellerService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SellerService.class);
	
	@Autowired
	SellerRepository sellerRepo;

	public ResponseEntity sellTrade(SellerEntity seller) {
		ResponseEntity responseModel = new ResponseEntity();
		seller.setTradeDate(new Date());
		
		seller = sellerRepo.save(seller);
		
		LOGGER.info("seller:"+seller);
		
		responseModel.setSuccessResponse("Product sale details completed successfully");
		
		return responseModel;
	}
}
