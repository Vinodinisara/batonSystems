package com.financial.services.batonsystems.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.entity.BuyerEntity;


/**
 * @author Vinodini
 * 
 *    Repository to save the requests to buy stocks
 *
 */
@Component
public interface BuyerRepository extends CrudRepository<BuyerEntity, String> {

	@Query("SELECT trade from BuyerEntity trade where trade.stock =:stock AND trade.price =:price")
	public List<BuyerEntity> findBySymbolPrice(@Param("stock") String stock, @Param("price") float price);

}
