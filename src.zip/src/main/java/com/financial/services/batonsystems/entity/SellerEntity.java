package com.financial.services.batonsystems.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
public class SellerEntity {

	@Id
	@GeneratedValue
	private int id;
	private String sellerId;
	private String stock;
	private float price;
	private Date tradeDate;
}
