package com.financial.services.batonsystems.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ResponseEntity {
	
	private String successResponse;
	private String error;

}
