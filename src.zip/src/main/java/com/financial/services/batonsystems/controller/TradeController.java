package com.financial.services.batonsystems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financial.services.batonsystems.entity.BuyerEntity;
import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.SellerEntity;
import com.financial.services.batonsystems.entity.TradeEntity;
import com.financial.services.batonsystems.service.BuyerService;
import com.financial.services.batonsystems.service.SellerService;

/**
 * @author Vinodini
 * 
 *         This is a controller class which redirects our incoming requests to
 *         the corresponding service class to implement our business needs
 *
 */
@RestController
@RequestMapping(value = "/v1")
public class TradeController {

	@Autowired
	SellerService sellerService;

	@Autowired
	BuyerService buyerService;
	
	/**
	 * Posts to buy the stocks available for sale
	 * 
	 * 
	 * @param buyer
	 * @returnType ResponseModel responseModel
	 */
	@PostMapping("/buyStocks")
	public ResponseModel createBuyer(@RequestBody BuyerEntity buyer) {
		ResponseModel responseModel = buyerService.buyTrade(buyer);
		return responseModel;
	}
	
	/**
	 * Posts to sell the available stocks for sale
	 * 
	 * 
	 * @param seller
	 * @returnType ResponseModel responseModel
	 */
	@PostMapping("/sellStocks")
	public ResponseModel createSeller(@RequestBody SellerEntity seller) {
		ResponseModel responseModel = sellerService.sellTrade(seller);
		return responseModel;
	}

	/**
	 * Fetches the trade details happend on basis of parties and symbols of stocks
	 * 
	 * @param sellerId
	 * @param buyerId
	 * @param symbol
	 * @returnType List<TradeEntity>
	 */
	@GetMapping("/trade/{sellerId}/{buyerId}/{symbol}")
	public List<TradeEntity> fetchTradesPartiesSymbol(@PathVariable String sellerId, @PathVariable String buyerId,
			@PathVariable String symbol) {
		return buyerService.matchedRecordsBySymbolPrice(symbol, sellerId, buyerId);
	}

	/**
	 * Fetches the non-trade details append on basis of price and symbols of stocks
	 * 
	 * @param symbol
	 * @param price
	 * @returnType List<BuyerEntity>
	 */
	@GetMapping("/trade/{symbol}/{price}")
	public List<BuyerEntity> fetchTradesSymbolPrice(@PathVariable String symbol, @PathVariable float price) {
		return buyerService.nonMatchedRecords(symbol, price);
	}

}
