package com.financial.services.batonsystems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financial.services.batonsystems.entity.BuyerEntity;
import com.financial.services.batonsystems.entity.TradeEntity;
import com.financial.services.batonsystems.entity.ResponseEntity;
import com.financial.services.batonsystems.entity.SellerEntity;
import com.financial.services.batonsystems.service.BuyerService;
import com.financial.services.batonsystems.service.SellerService;

@RestController
@RequestMapping(value="/v1")
public class TradeController {
	
	@Autowired
	SellerService sellerService;
	
	@Autowired
	BuyerService buyerService;
	
	
	@PostMapping("/buyStocks")
	public ResponseEntity createBuyer(@RequestBody BuyerEntity buyer) {
		ResponseEntity responseModel = buyerService.buyTrade(buyer);
		return responseModel;
	}
	
	@PostMapping("/sellStocks")
	public ResponseEntity createSeller(@RequestBody SellerEntity seller) {
		ResponseEntity responseModel = sellerService.sellTrade(seller);
		return responseModel;
	}
	
	@GetMapping("/trade/{sellerId}/{buyerId}/{symbol}")
	public List<TradeEntity> fetchTradesPartiesSymbol(@PathVariable String sellerId, @PathVariable String buyerId,
			@PathVariable String symbol) {
		return buyerService.matchedRecordsBySymbolPrice(symbol, sellerId, buyerId);
	}
	
	@GetMapping("/trade/{symbol}/{price}")
	public List<BuyerEntity> fetchTradesSymbolPrice(@PathVariable String symbol, @PathVariable float price) {
		return buyerService.nonMatchedRecords(symbol, price);
	}

}
