package com.financial.services.batonsystems.serviceImpl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.dao.SellerRepository;
import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.SellerEntity;
import com.financial.services.batonsystems.service.SellerService;

/**
 * @author Vinodini
 * 
 *         This is a service implementation class for stocks selling
 *
 */
@Component
public class SellerServiceImpl implements SellerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SellerServiceImpl.class);

	@Autowired
	SellerRepository sellerRepo;
	
	
	/**
	 * Posts to sell the available stocks for sale
	 * 
	 * 
	 * @param seller
	 * @returnType ResponseModel responseModel
	 */
	@Override
	public ResponseModel sellTrade(SellerEntity seller) {
		ResponseModel responseModel = new ResponseModel();
		seller.setTradeDate(new Date());

		seller = sellerRepo.save(seller);

		LOGGER.info("seller:" + seller);

		responseModel.setSuccessResponse("Product sale details completed successfully");

		return responseModel;
	}
}
