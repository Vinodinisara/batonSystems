package com.financial.services.batonsystems.serviceImpl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.financial.services.batonsystems.dao.SellerRepository;
import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.SellerEntity;
import com.financial.services.batonsystems.service.SellerService;

public class SellerServiceImpl implements SellerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SellerServiceImpl.class);

	@Autowired
	SellerRepository sellerRepo;

	@Override
	public ResponseModel sellTrade(SellerEntity seller) {
		ResponseModel responseModel = new ResponseModel();
		seller.setTradeDate(new Date());

		seller = sellerRepo.save(seller);

		LOGGER.info("seller:" + seller);

		responseModel.setSuccessResponse("Product sale details completed successfully");

		return responseModel;
	}
}
