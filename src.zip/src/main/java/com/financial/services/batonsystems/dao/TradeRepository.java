package com.financial.services.batonsystems.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.financial.services.batonsystems.entity.TradeEntity;


/**
 * @author Vinodini
 * 
 *    Repository to see if records matched for trade
 *
 */
@Component
public interface TradeRepository extends CrudRepository<TradeEntity, String> {

	@Query("SELECT trade from TradeEntity trade where trade.stock =:stock AND (trade.sellerId =:sellerId AND trade.buyerId =:buyerId)")
	public List<TradeEntity> findBySymbolParty(@Param("stock") String stock, @Param("sellerId") String sellerId,
			@Param("buyerId") String buyerId);

}
