package com.financial.services.batonsystems.serviceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.financial.services.batonsystems.dao.BuyerRepository;
import com.financial.services.batonsystems.dao.SellerRepository;
import com.financial.services.batonsystems.dao.TradeRepository;
import com.financial.services.batonsystems.entity.BuyerEntity;
import com.financial.services.batonsystems.entity.ResponseModel;
import com.financial.services.batonsystems.entity.SellerEntity;
import com.financial.services.batonsystems.entity.TradeEntity;
import com.financial.services.batonsystems.service.BuyerService;

@Component
public class BuyerServiceImpl implements BuyerService{
	private static final Logger LOGGER = LoggerFactory.getLogger(BuyerServiceImpl.class);
	
	@Autowired
	BuyerRepository buyerRepo;
	
	@Autowired
	SellerRepository sellerRepo;
	
	@Autowired
	TradeRepository matchedRepo;
	
	
	@Override
	public ResponseModel buyTrade(BuyerEntity buyer) {
		ResponseModel responseModel = new ResponseModel();
		
		List<SellerEntity> resultSeller = new ArrayList<SellerEntity>();
		sellerRepo.findAll().forEach(resultSeller::add);
		
		if(!ObjectUtils.isEmpty(resultSeller)) {
			buyer.setTradeDate(new Date());		
			buyer = buyerRepo.save(buyer);
			
			LOGGER.info("buyer:"+buyer);
			
			List<BuyerEntity> buyDet = buyDetails(resultSeller);
			
			LOGGER.info("buyDet:"+buyDet);
			
			responseModel.setSuccessResponse("Product sale details completed successfully");
		} else {
			responseModel.setError("No stocks available for sale");
		}
		
		return responseModel;
		
	}
	
	
	private List<BuyerEntity> buyDetails(List<SellerEntity> resultSeller) {
		 List<BuyerEntity> resultBuyer = new ArrayList<BuyerEntity>();
		 buyerRepo.findAll().forEach(resultBuyer::add);
		 
		 LinkedHashMap<String, BuyerEntity> buyerCpy = new LinkedHashMap<String, BuyerEntity>();
		 for(BuyerEntity buyDet : resultBuyer) {
			 buyerCpy.put(buyDet.getStock(), buyDet);
		 }
		 
		 LinkedHashMap<String, SellerEntity> sellerCpy = new LinkedHashMap<String, SellerEntity>();
		 for(SellerEntity sellDet : resultSeller) {
			 sellerCpy.put(sellDet.getStock(), sellDet);
		 }
		 
		List<BuyerEntity> response = matchedRecords(resultBuyer, resultSeller);
		return response;		
	}
	
	private List<BuyerEntity> matchedRecords(List<BuyerEntity> resultBuyer, List<SellerEntity> resultSeller) {
		List<Date> tradeDateSort = new ArrayList<Date>();
		for(BuyerEntity buyDet: resultBuyer) {
			for(SellerEntity sellDet: resultSeller) {
				if(sellDet.getStock().equals(buyDet.getStock())
						&& buyDet.getPrice() == sellDet.getPrice()) {
					tradeDateSort.add(buyDet.getTradeDate());
					Collections.sort(tradeDateSort);
					LOGGER.info("tradeDateSort:"+tradeDateSort);
					if(buyDet.getTradeDate().equals(tradeDateSort.get(0))) {
						TradeEntity matchedModel = new TradeEntity();
						matchedModel.setBuyerId(buyDet.getBuyerId());
						matchedModel.setPrice(buyDet.getPrice());
						matchedModel.setSellerId(sellDet.getSellerId());
						matchedModel.setStock(sellDet.getStock());
						matchedModel.setTradeDate(buyDet.getTradeDate());
						matchedRepo.save(matchedModel);
						
						LOGGER.info("matchedModel:"+matchedModel);
					}
					buyerRepo.delete(buyDet);
					sellerRepo.delete(sellDet);
					
					LOGGER.info("buyerFinalResult:"+buyDet);
				}
			}
		}
		 return resultBuyer;
	}
	
	@Override
	public List<TradeEntity> matchedRecordsBySymbolPrice(String symbol, String sellerId, String buyerId) {
		return matchedRepo.findBySymbolParty(symbol, sellerId, buyerId);
	}
	
	@Override
	public List<BuyerEntity> nonMatchedRecords(String symbol, float price) {
		return buyerRepo.findBySymbolPrice(symbol, price);
	}
}
